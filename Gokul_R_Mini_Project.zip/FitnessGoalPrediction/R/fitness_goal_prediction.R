# =====================================================================
# Fitness Goal and Calorie Prediction using R
# Course : 23CAP317 - R Programming (Mini Project)
# Data   : Fitbit Fitness Tracker Data (Kaggle / Amazon Mechanical Turk)
# Targets: (1) Calories  -> regression  (numeric)
#          (2) GoalAchieved (10,000 steps/day) -> classification (0/1)
# Run    : setwd("FitnessGoalPrediction"); source("R/fitness_goal_prediction.R")
# Needs  : install.packages(c("ggplot2","corrplot","caret","ranger"))
# =====================================================================
suppressPackageStartupMessages({
  library(ggplot2); library(corrplot); library(caret); library(ranger)
})
set.seed(123)
dir.create("outputs/figures", showWarnings = FALSE, recursive = TRUE)
save_plot <- function(p, name) ggsave(file.path("outputs/figures", name), p, width = 7, height = 4.5, dpi = 150)

# ---------------------------------------------------------------------
# Q1. DATA STRUCTURES  (vector, matrix, list, factor, data frame)
# ---------------------------------------------------------------------
cat("\n######## Q1. DATA STRUCTURES ########\n")
steps_vec   <- c(11004, 17609, 12736, 13231, 12041)                                   # vector
goal_factor <- factor(c("Yes","Yes","Yes","Yes","Yes","No"), levels = c("No","Yes"))  # factor
act_matrix  <- matrix(c(33,89,56, 12,17,5, 205,274,268), nrow = 3,
                      dimnames = list(paste0("Day", 1:3), c("VeryActive","FairlyActive","LightlyActive")))  # matrix
user_list   <- list(id = 1503960366, days = 3, avg_steps = mean(steps_vec[1:3]))      # list
cat("Vector  :", steps_vec, "\n"); print(act_matrix); str(user_list); print(table(goal_factor))

# ---- Load, merge and inspect (data frames) ----
a1    <- read.csv("data/raw/dailyActivity_period1.csv")
a2    <- read.csv("data/raw/dailyActivity_period2.csv")
sleep <- read.csv("data/raw/sleepDay_period2.csv")
act   <- rbind(a1, a2)
act$Date   <- as.Date(act$ActivityDate, format = "%m/%d/%Y")
sleep$Date <- as.Date(sleep$SleepDay, format = "%m/%d/%Y")
fit <- merge(act, sleep[, c("Id","Date","TotalMinutesAsleep","TotalTimeInBed")],
             by = c("Id","Date"), all.x = TRUE)                                       # left join
cat("\nDimensions :", dim(fit), "\n"); cat("Users      :", length(unique(fit$Id)), "\n")
print(head(fit[, c("Id","Date","TotalSteps","VeryActiveMinutes","SedentaryMinutes","Calories")]))
str(fit)

# ---------------------------------------------------------------------
# Q2. CONTROL STRUCTURES, FUNCTIONS, LISTS, DATA FRAMES
# ---------------------------------------------------------------------
cat("\n######## Q2. CONTROL STRUCTURES & FUNCTIONS ########\n")
# --- user-defined functions ---
rmse <- function(actual, pred) sqrt(mean((actual - pred)^2))
r2   <- function(actual, pred) 1 - sum((actual - pred)^2) / sum((actual - mean(actual))^2)
activity_level <- function(steps) {                 # if / else if / else
  if (steps < 5000) "Sedentary" else if (steps < 7500) "Low active"
  else if (steps < 10000) "Somewhat active" else "Active"
}
# --- for loop ---
fit$Level <- character(nrow(fit))
for (i in seq_len(nrow(fit))) fit$Level[i] <- activity_level(fit$TotalSteps[i])
fit$Level <- factor(fit$Level, levels = c("Sedentary","Low active","Somewhat active","Active"))
print(table(fit$Level))
# --- while loop: row at which the 5th 'Active' day is found ---
count <- 0; k <- 0
while (count < 5) { k <- k + 1; if (fit$Level[k] == "Active") count <- count + 1 }
cat("5th 'Active' day found at row:", k, "\n")
# --- apply family on a list ---
by_user <- split(fit$TotalSteps, fit$Id)             # list of vectors
avg_steps_user <- sapply(by_user, mean)
cat("Top 3 users by average steps/day:\n"); print(round(head(sort(avg_steps_user, decreasing = TRUE), 3)))
print(round(apply(fit[, c("TotalSteps","Calories","SedentaryMinutes")], 2, median), 1))
print(aggregate(Calories ~ Level, data = fit, FUN = mean))

# ---------------------------------------------------------------------
# STAGE 1. DATA CLEANING
# ---------------------------------------------------------------------
cat("\n######## STAGE 1. DATA CLEANING ########\n")
cat("Missing values per column (non-zero only):\n"); na_sum <- colSums(is.na(fit)); print(na_sum[na_sum > 0])
cat("Duplicate rows:", sum(duplicated(fit)), "\n")
fit <- fit[!duplicated(fit), ]                           # caused by repeated rows in sleep log
nonwear <- fit$TotalSteps == 0 | fit$Calories < 1000     # tracker not worn
cat("Non-wear days removed:", sum(nonwear), "\n")
fit <- fit[!nonwear, ]
fit$HasSleepRecord <- as.integer(!is.na(fit$TotalMinutesAsleep))
fit$SleepHours <- fit$TotalMinutesAsleep / 60
fit$SleepHours[is.na(fit$SleepHours)] <- median(fit$SleepHours, na.rm = TRUE)   # median imputation
fit$Weekend <- as.integer(weekdays(fit$Date) %in% c("Saturday","Sunday"))
fit$GoalAchieved <- as.integer(fit$TotalSteps >= 10000)                          # target 2
cat("Rows after cleaning:", nrow(fit), "\n"); print(table(fit$GoalAchieved))
cat("Goal achieved (%):", round(100 * mean(fit$GoalAchieved), 1), "\n")
write.csv(fit, "data/fitness_clean.csv", row.names = FALSE)

# ---------------------------------------------------------------------
# Q3. STATISTICAL PROBLEMS
# ---------------------------------------------------------------------
cat("\n######## Q3. STATISTICAL ANALYSIS ########\n")
num_cols <- c("TotalSteps","VeryActiveMinutes","FairlyActiveMinutes","LightlyActiveMinutes",
              "SedentaryMinutes","SleepHours","Calories")
print(round(sapply(fit[, num_cols], function(x) c(mean = mean(x), sd = sd(x), median = median(x))), 2))
sh <- shapiro.test(sample(fit$Calories, 1000)); cat("\n(a) Shapiro-Wilk Calories: W =", round(sh$statistic, 4), " p =", signif(sh$p.value, 3), "\n")
ct <- cor.test(fit$TotalSteps, fit$Calories); cat("(b) Cor(Steps, Calories) r =", round(ct$estimate, 3), " p =", signif(ct$p.value, 3), "\n")
tt <- t.test(Calories ~ GoalAchieved, data = fit)
cat("(c) t-test Calories by Goal: t =", round(tt$statistic, 2), " p =", signif(tt$p.value, 3), "\n")
cs <- chisq.test(table(fit$Weekend, fit$GoalAchieved))
cat("(d) Chi-square Weekend vs Goal: X2 =", round(cs$statistic, 2), " p =", round(cs$p.value, 4), "\n")
fit$Day <- factor(weekdays(fit$Date), levels = c("Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"))
an <- summary(aov(TotalSteps ~ Day, data = fit)); cat("(e) ANOVA Steps ~ Weekday: F =", round(an[[1]]$`F value`[1], 2), " p =", round(an[[1]]$`Pr(>F)`[1], 4), "\n")
iqr_out <- sapply(fit[, num_cols], function(x) { q <- quantile(x, c(.25,.75)); sum(x < q[1]-1.5*diff(q) | x > q[2]+1.5*diff(q)) })
cat("(f) IQR outliers per variable:\n"); print(iqr_out)
preds <- c("VeryActiveMinutes","FairlyActiveMinutes","LightlyActiveMinutes","SedentaryMinutes","TotalSteps","SleepHours")
vif <- sapply(preds, function(v) 1 / (1 - summary(lm(reformulate(setdiff(preds, v), v), data = fit))$r.squared))
cat("(g) VIF:\n"); print(round(vif, 2))
cat("(h) Days with sleep record:", round(100 * mean(fit$HasSleepRecord), 1), "%\n")

# ---- plots ----
save_plot(ggplot(fit, aes(Calories)) + geom_histogram(bins = 40, fill = "#1B7F79", colour = "white") +
            ggtitle("Distribution of Calories Burned"), "01_calories_hist.png")
cm <- cor(fit[, num_cols]); png("outputs/figures/02_correlation.png", 1000, 900, res = 130)
corrplot(cm, method = "color", addCoef.col = "black", number.cex = 0.6, tl.cex = 0.7, tl.col = "black"); dev.off()
long <- stack(fit[, c("VeryActiveMinutes","FairlyActiveMinutes","LightlyActiveMinutes")])
save_plot(ggplot(long, aes(ind, values)) + geom_boxplot(fill = "#F2A65A") + labs(x = "", y = "Minutes", title = "Boxplots of Active Minutes (outlier check)"), "03_boxplots.png")
save_plot(ggplot(fit, aes(TotalSteps, Calories, colour = factor(GoalAchieved))) + geom_point(alpha = .5) +
            scale_colour_manual(values = c("#9aa5b1","#1B7F79"), labels = c("Not achieved","Achieved"), name = "10k goal") +
            ggtitle("Steps vs Calories"), "04_steps_calories.png")
save_plot(ggplot(aggregate(TotalSteps ~ Day, fit, mean), aes(Day, TotalSteps)) + geom_col(fill = "#1B7F79") +
            labs(x = "", y = "Average steps", title = "Average Steps by Day of Week"), "05_steps_by_day.png")

# ---------------------------------------------------------------------
# STAGE 4. DATA SPLITTING (80/20)
# ---------------------------------------------------------------------
cat("\n######## DATA SPLITTING ########\n")
idx   <- createDataPartition(fit$Calories, p = 0.8, list = FALSE)
reg_x <- c("TotalSteps","VeryActiveMinutes","FairlyActiveMinutes","LightlyActiveMinutes","SedentaryMinutes","SleepHours","Weekend")
train <- fit[idx, ]; test <- fit[-idx, ]
cat("Train rows:", nrow(train), "| Test rows:", nrow(test), "\n")

# ---------------------------------------------------------------------
# Q4. REGRESSION MODELS  -> target 1: Calories
# ---------------------------------------------------------------------
cat("\n######## Q4. REGRESSION MODELS (Calories) ########\n")
m_simple <- lm(Calories ~ TotalSteps, data = train)                      # Model 1
m_multi  <- lm(reformulate(reg_x, "Calories"), data = train)             # Model 2
print(summary(m_multi))
m_step   <- step(m_multi, direction = "both", trace = 0)                 # Model 3
cat("Stepwise kept:", paste(attr(terms(m_step), "term.labels"), collapse = ", "), "\n")
m_poly   <- lm(Calories ~ poly(TotalSteps, 2) + VeryActiveMinutes + FairlyActiveMinutes +
                 LightlyActiveMinutes + SedentaryMinutes, data = train)  # Model 4
m_rf     <- ranger(reformulate(reg_x, "Calories"), data = train, num.trees = 300,
                   importance = "impurity", seed = 123)                  # Model 5

res <- data.frame(Model = c("Simple Linear","Multiple Linear","Stepwise Linear","Polynomial (deg 2)","Random Forest"),
                  RMSE = NA, R2 = NA, MAE = NA)
pl <- list(predict(m_simple, test), predict(m_multi, test), predict(m_step, test), predict(m_poly, test),
           predict(m_rf, test)$predictions)
for (i in seq_along(pl)) { res$RMSE[i] <- rmse(test$Calories, pl[[i]]); res$R2[i] <- r2(test$Calories, pl[[i]]); res$MAE[i] <- mean(abs(test$Calories - pl[[i]])) }
res[, 2:4] <- round(res[, 2:4], 3); cat("\nTest-set performance:\n"); print(res)
write.csv(res, "outputs/regression_results.csv", row.names = FALSE)
cat("Best model by RMSE:", res$Model[which.min(res$RMSE)], "\n")

imp <- sort(m_rf$variable.importance, decreasing = TRUE); cat("\nRandom forest importance:\n"); print(round(imp, 0))
save_plot(ggplot(data.frame(Var = factor(names(imp), levels = rev(names(imp))), Imp = imp), aes(Var, Imp)) +
            geom_col(fill = "#1B7F79") + coord_flip() + labs(x = "", y = "Importance", title = "Random Forest Variable Importance"), "06_rf_importance.png")
save_plot(ggplot(data.frame(Obs = test$Calories, Pred = pl[[2]]), aes(Obs, Pred)) + geom_point(alpha = .5, colour = "#1B7F79") +
            geom_abline(colour = "red") + ggtitle("Multiple Linear Regression: Predicted vs Actual"), "07_lm_pred_actual.png")
save_plot(ggplot(data.frame(Obs = test$Calories, Pred = pl[[5]]), aes(Obs, Pred)) + geom_point(alpha = .5, colour = "#F2A65A") +
            geom_abline(colour = "red") + ggtitle("Random Forest: Predicted vs Actual"), "08_rf_pred_actual.png")
save_plot(ggplot(data.frame(Fit = fitted(m_multi), Res = resid(m_multi)), aes(Fit, Res)) + geom_point(alpha = .4) +
            geom_hline(yintercept = 0, colour = "red") + ggtitle("Residuals vs Fitted (Multiple Linear)"), "09_residuals.png")

# ---------------------------------------------------------------------
# LOGISTIC REGRESSION -> target 2: GoalAchieved
# (steps & distance are NOT used as predictors: they define the goal = data leakage)
# ---------------------------------------------------------------------
cat("\n######## LOGISTIC REGRESSION (10,000-step goal) ########\n")
cl_x  <- c("VeryActiveMinutes","FairlyActiveMinutes","LightlyActiveMinutes","SedentaryMinutes","Calories","SleepHours","Weekend")
glm_m <- glm(reformulate(cl_x, "GoalAchieved"), data = train, family = binomial)
print(round(summary(glm_m)$coefficients[, c(1, 4)], 4))
cat("Odds ratios:\n"); print(round(exp(coef(glm_m)), 3))
prob  <- predict(glm_m, test, type = "response")
pred  <- factor(ifelse(prob > 0.5, 1, 0), levels = c(0, 1)); ref <- factor(test$GoalAchieved, levels = c(0, 1))
cm_g  <- confusionMatrix(pred, ref, positive = "1"); print(cm_g)
rf_c  <- ranger(reformulate(cl_x, "GoalAchieved"), data = transform(train, GoalAchieved = factor(GoalAchieved)),
                num.trees = 300, probability = TRUE, seed = 123)
prob_rf <- predict(rf_c, test)$predictions[, "1"]
pred_rf <- factor(ifelse(prob_rf > 0.5, 1, 0), levels = c(0, 1)); cm_rf <- confusionMatrix(pred_rf, ref, positive = "1")
auc <- function(p, y) { r <- rank(p); n1 <- sum(y == 1); n0 <- sum(y == 0); (sum(r[y == 1]) - n1 * (n1 + 1) / 2) / (n1 * n0) }
class_res <- data.frame(Model = c("Logistic Regression","Random Forest"),
  Accuracy = round(c(cm_g$overall["Accuracy"], cm_rf$overall["Accuracy"]), 4),
  F1  = round(c(cm_g$byClass["F1"], cm_rf$byClass["F1"]), 4),
  AUC = round(c(auc(prob, test$GoalAchieved), auc(prob_rf, test$GoalAchieved)), 4))
cat("\nClassification results:\n"); print(class_res)
write.csv(class_res, "outputs/classification_results.csv", row.names = FALSE)
save_plot(ggplot(as.data.frame(cm_g$table), aes(Reference, Prediction, fill = Freq)) + geom_tile() + geom_text(aes(label = Freq), size = 6) +
            scale_fill_gradient(low = "#e8f3f2", high = "#1B7F79") + ggtitle("Logistic Regression: Confusion Matrix"), "10_confusion_matrix.png")

# ---------------------------------------------------------------------
# Q5. PREDICTION ON NEW DATA + SAVE MODELS
# ---------------------------------------------------------------------
cat("\n######## Q5. PREDICTION FOR NEW USERS ########\n")
predict_fitness <- function(steps, very, fairly, lightly, sedentary, sleep_hrs, weekend) {
  nd  <- data.frame(TotalSteps = steps, VeryActiveMinutes = very, FairlyActiveMinutes = fairly,
                    LightlyActiveMinutes = lightly, SedentaryMinutes = sedentary, SleepHours = sleep_hrs, Weekend = weekend)
  cal <- predict(m_rf, nd)$predictions
  nd$Calories <- cal
  p   <- predict(glm_m, nd, type = "response")
  data.frame(PredCalories = round(cal), GoalProbability = round(p, 3), Goal = ifelse(p > 0.5, "Achieved", "Not achieved"))
}
new_users <- data.frame(Profile = c("Office worker", "Regular jogger", "Weekend walker"),
                        steps = c(4500, 12500, 9000), very = c(0, 45, 10), fairly = c(5, 20, 15),
                        lightly = c(150, 230, 260), sedentary = c(900, 650, 700), sleep = c(6.2, 7.5, 8), weekend = c(0, 0, 1))
out <- cbind(new_users[, 1, drop = FALSE],
             do.call(rbind, lapply(seq_len(nrow(new_users)), function(i)
               with(new_users[i, ], predict_fitness(steps, very, fairly, lightly, sedentary, sleep, weekend)))))
rownames(out) <- NULL; print(out)
write.csv(out, "outputs/new_user_predictions.csv", row.names = FALSE)
saveRDS(m_rf, "outputs/rf_calorie_model.rds"); saveRDS(glm_m, "outputs/glm_goal_model.rds")
cat("\nDone. Figures in outputs/figures, tables in outputs/\n")
