# Fitness Goal and Calorie Prediction using R

23CAP317 - R Programming Mini Project (MCA, Karpagam College of Engineering)

Predicts **daily calories burned** (regression) and whether a user **achieves the 10,000-step goal** (classification)
from Fitbit tracker data, using linear, polynomial, stepwise, random forest and logistic regression models.

## Folder structure
| Path | Content |
|---|---|
| `R/fitness_goal_prediction.R` | Complete script (Q1 to Q5) |
| `data/raw/` | Original Fitbit CSV files (dailyActivity x2, sleepDay) |
| `data/fitness_clean.csv` | Cleaned dataset created by the script |
| `outputs/` | Figures, result tables, new-user predictions, saved models, `console_output.txt` |
| `docs/` | Word report and PPT |

## How to run
```r
install.packages(c("ggplot2", "corrplot", "caret", "ranger"))
setwd("FitnessGoalPrediction")          # project root
source("R/fitness_goal_prediction.R")
```
Expected final lines:
```
Test-set performance:  Random Forest  RMSE 422.337  R2 0.655
Classification results: Random Forest Accuracy 0.898  AUC 0.9612
Done. Figures in outputs/figures, tables in outputs/
```
(`set.seed(123)` is used. Small differences are possible on other R / package versions.)

## Key results
| Task | Best model | Metrics (test set) |
|---|---|---|
| Calories | Random Forest | R2 0.655, RMSE 422 kcal, MAE 339 kcal |
| 10,000-step goal | Random Forest | Accuracy 0.898, F1 0.834, AUC 0.961 |

Steps and distances are not used to predict the step goal (data leakage).

## Data source
Fitbit Fitness Tracker Data, Kaggle (Mobius), Amazon Mechanical Turk survey, 12 March - 12 May 2016.

## Upload to GitHub
```bash
git init
git add .
git commit -m "Fitness goal prediction in R"
git branch -M main
git remote add origin https://github.com/<your-username>/Fitness-Goal-Prediction-R.git
git push -u origin main
```
